function send(){
n1=document.getElementById("n1").value;
n2=document.getElementById("n2").value;
a=parseInt(n1)*parseInt(n2);
q_n="<h4>" + n1 + "X" + n2 + "</h4>";
i="<br>Answer : <input id='Answer_input' type='number' style='width:200px' class='form-control'>";
c="<br><br> <button id='check_button' class='btn btn-success'>Check your answer</button>"
row = q_n+i+c;
document.getElementById("output").innerHTML=row;
document.getElementById("n1").value="";
document.getElementById("n2").value="";
}